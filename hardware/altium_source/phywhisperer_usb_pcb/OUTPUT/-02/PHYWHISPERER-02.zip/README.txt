4-Layer PCB

Soldermask: Green
Silkscreen: White

Finish: Immersion Gold

Individual PCB Size: 82.6mm x 56.6mm
Board Files:

 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .G1 - Inner Layer 1
 .G2 - Inner Layer 2
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .GM1 - PCB Outline
 .NCDRILL - Drill Files (round & slot)


Other Files:

 .GTP - Top Paste (used for stencil)
 .GBP - Bottom Paste (used for stencil)